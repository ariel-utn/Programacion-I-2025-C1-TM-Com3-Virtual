#include <iostream>
#include "juego.h"

using namespace std;


void jugar(int &maximoPuntaje)
{
    cout << "Inicia el juego" << endl;
    int valoresDados = 6;
    const int TAM = 5;
    int tirada[TAM];
    int puntosTotalesJugador1 = 0;
    int puntosTotalesJugador2 = 0;

    for(int turno = 1; turno <= 3; turno++)
    {
        for(int jugador = 1; jugador <= 2; jugador++)
        {
            cout << "Turno #" << turno << endl;
            if(jugador==1)
            {
                cout << "Jugador 1" << endl;
                generarTiradaDados(tirada, TAM, valoresDados);
                mostrarTiradaDados(tirada, TAM);
                puntosTotalesJugador1 += obtenerPuntosTirada(tirada, TAM);
            }
            if(jugador==2)
            {
                cout << "Jugador 2" << endl;
                generarTiradaDados(tirada, TAM, valoresDados);
                mostrarTiradaDados(tirada, TAM);
                puntosTotalesJugador2 += obtenerPuntosTirada(tirada, TAM);
            }
        }
    }
    cout << "Total puntos obtenidos J1: " << puntosTotalesJugador1 << endl;
    cout << "Total puntos obtenidos J2: " << puntosTotalesJugador2 << endl;

    mostrarGanador(puntosTotalesJugador1,puntosTotalesJugador2);
    maximoPuntaje = obtenerPuntosGanador(puntosTotalesJugador1,puntosTotalesJugador2);
}

int generarNumeroAleatorio(int rango)
{
    return (rand()%rango) + 1 ;
}

void generarTiradaDados(int v[], int t, int rango)
{
    for(int i = 0; i < t; i++)
    {
        v[i] = generarNumeroAleatorio(rango);
    }
}

void mostrarTiradaDados(int v[], int t)
{
    for(int i = 0; i < t; i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

int obtenerPuntosTirada(int v[], int t)
{
    int puntos = 0, i;
    for(i = 0; i < t; i++)
    {
        puntos += v[i];
    }
    return puntos;
}

void mostrarGanador(int puntosJ1, int puntosJ2){
    if(puntosJ1 > puntosJ2){
        cout << "El ganador es: " << "Jugador 1" << endl;
    }
    if(puntosJ1 < puntosJ2){
        cout << "El ganador es: " << "Jugador 2" << endl;
    }
    if (puntosJ1==puntosJ2){
        cout << "Empate" << endl;
    }
}

int obtenerPuntosGanador(int puntosJ1, int puntosJ2){
    if(puntosJ1>puntosJ2){
        return puntosJ1;
    }
    return puntosJ2;
}
