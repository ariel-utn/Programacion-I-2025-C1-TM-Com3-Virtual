#include <iostream>
#include "estadisticas.h"

using namespace std;

void estadisticas(int &maximo, int maximoPuntaje){
    if(maximoPuntaje > maximo){
        maximo = maximoPuntaje;
    }
    if(maximo==0){
        cout << "Debe empezar el juego" << endl;
    }
    cout << "El maximo puntaje es: " << maximo << endl;
}
