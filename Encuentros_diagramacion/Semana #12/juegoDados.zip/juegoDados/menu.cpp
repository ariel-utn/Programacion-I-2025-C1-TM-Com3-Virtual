#include <iostream>
#include "estadisticas.h"
#include "menu.h"
#include "juego.h"

using namespace std;

void menu(int maximo){
    int opcion;
    int maximoPuntaje;

    do{
    system("cls");
    opciones();
    cout << "Ingrese opcion:";
    cin >> opcion;
    switch(opcion){
        case 1:{
            jugar(maximoPuntaje);
        } break;
        case 2:{
            estadisticas(maximo, maximoPuntaje);
        }break;
        case 3:{
            cout << "Gracias por jugar!!!!" << endl;
            return;
        }break;
        default:{
            cout << "Opcion invalida" << endl;
        }break;

    }
    system("pause");
    } while(true);
}

void opciones(){
cout <<"-----------------"<< endl;
cout <<"|1- JUGAR       |"<< endl;
cout <<"|2- ESTADISTICAS|"<< endl;
cout <<"|3- SALIR       |"<< endl;
cout <<"-----------------"<< endl;
}
