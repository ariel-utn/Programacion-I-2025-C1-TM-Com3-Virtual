#ifndef JUEGO_H_INCLUDED
#define JUEGO_H_INCLUDED

void jugar(int &maximoPuntaje);
int generarNumeroAleatorio(int rango);
void generarTiradaDados(int v[], int t, int rango);
void mostrarTiradaDados(int v[], int t);
int obtenerPuntosTirada(int v[], int t);
void mostrarGanador(int puntosJ1, int puntosJ2);
int obtenerPuntosGanador(int puntosJ1, int puntosJ2);

#endif // JUEGO_H_INCLUDED
