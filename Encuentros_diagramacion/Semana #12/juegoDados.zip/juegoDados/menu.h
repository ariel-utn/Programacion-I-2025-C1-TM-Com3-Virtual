#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

/// SOLO VAN LAS DECLARACION DE LAS FUNCIONES
void menu(int maximo);
void opciones();


#endif // MENU_H_INCLUDED
