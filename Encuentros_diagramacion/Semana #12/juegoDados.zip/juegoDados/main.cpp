#include <iostream>
#include <ctime>
#include "menu.h"

using namespace std;

int main()
{
    int maximo = 0;
    /// SEMILLA: UNA UNICA EN EL MAIN
    srand(time(nullptr));

    menu(maximo);

    return 0;
}
