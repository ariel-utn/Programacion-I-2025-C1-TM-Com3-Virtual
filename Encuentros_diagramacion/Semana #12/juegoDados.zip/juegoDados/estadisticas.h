#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED

void estadisticas(int &maximo, int maximoPuntaje);

#endif // ESTADISTICAS_H_INCLUDED
